# Simple NeuralNet

A simple Python library for creating and training neural networks using TensorFlow.

## Installation

```bash
pip install -e .